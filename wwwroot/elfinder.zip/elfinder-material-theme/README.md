# elFinder-Material-Theme

A theme for the elFinder web file manager inspired by Google Material design.

[Install guide](https://github.com/Studio-42/elFinder/wiki/How-to-load-CSS-with-RequireJS%3F)

![Visitor Badge](https://visitor-badge.laobi.icu/badge?page_id=RobiNN1.elFinder-Material-Theme)

<table>
  <tr>
    <td><img alt="Default" src=".github/img/preview-default.png"></td>
    <td><img alt="Gray" src=".github/img/preview-gray.png"></td>
    <td><img alt="Light" src=".github/img/preview-light.png"></td>
  </tr>
</table>
